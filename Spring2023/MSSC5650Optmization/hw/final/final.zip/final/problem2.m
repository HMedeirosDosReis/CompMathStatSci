%note: the file mystery_function.p needs to be in the 
%current folder for this script to work.
[f,grad] = mystery_function; %load mystery function and gradient
x = zeros(500,1); %fixed initialization

% define algorithm parameters here

cost = f(x); %initialize cost array
for k=1:1000
    g = grad(x);
    
    %your algorithm goes here

    cost = [cost,f(x)];
end
fprintf('f(x) = %8.6f\n',f(x));
fprintf('number of gradient calls = %d\n',grad('count'));

figure(1); %plot the cost 
semilogy(cost,'linewidth',2);
title('cost vs. iteration');
set(gca,'fontsize',14);